#-------------------------------------------------------------------------------------------
#--- Sniffer de Red Profesional - UI Rediseñada y Responsiva (Comercial/Moderna)         ---
#--- Interfaz: Dark terminal aesthetic con acentos neón, tipografía refinada             ---
#--- v2.2: selector de tarjeta (WiFi/Ethernet) + análisis de HTTP, NFS, DNS y DHCP      ---
#--- v2.3: detalle completo de ICMPv4 e ICMPv6 (incl. Neighbor Discovery)               ---
#--- Optimización: Layout 100% responsivo adaptable a cualquier resolución de pantalla   ---
#-------------------------------------------------------------------------------------------
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, font
import threading
import logging
import platform
import subprocess
import os
import re
import time
import queue
import socket
import struct
from scapy.all import (AsyncSniffer, IP, IPv6, TCP, UDP, ICMP, Ether, ARP, Raw,
                       DNS, BOOTP, DHCP, conf, IPerror, TCPerror, UDPerror)
from scapy.packet import Packet, NoPayload
import psutil

try:  # netifaces ya es opcional: en Linux el gateway se lee de /proc/net/route
    import netifaces
except ImportError:
    netifaces = None

logging.getLogger("scapy.runtime").setLevel(logging.ERROR)

# ============================================================
# --- Paleta de colores y tokens de diseño               ---
# ============================================================
COLORS = {
    # Backgrounds
    "bg_base":       "#080c10",
    "bg_surface":    "#0d1117",
    "bg_elevated":   "#141b24",
    "bg_card":       "#0f1923",
    "bg_hover":      "#1a2535",

    # Bordes
    "border_dim":    "#1e2d3d",
    "border_mid":    "#1f3a52",
    "border_glow":   "#00e5ff",

    # Texto
    "text_primary":  "#e8f4f8",
    "text_secondary":"#7fa8c0",
    "text_dim":      "#3d6070",
    "text_mono":     "#a8d8ea",

    # Acentos
    "accent_cyan":   "#00e5ff",
    "accent_green":  "#00ff88",
    "accent_amber":  "#ffab00",
    "accent_red":    "#ff3355",
    "accent_blue":   "#4d9fff",

    # Protocolo tags
    "proto_tcp":     "#00e5ff",
    "proto_udp":     "#00ff88",
    "proto_icmp":    "#ffab00",
    "proto_arp":     "#ff55ff", 
    "proto_other":   "#7fa8c0",

    # Protocolos de aplicación (capa 7)
    "proto_http":    "#ff8a3d",
    "proto_dns":     "#b794f6",
    "proto_dhcp":    "#2dd4bf",
    "proto_nfs":     "#ff7a7a",
}


# ============================================================
# --- Constantes de captura y filtros de protocolo         ---
# ============================================================
MAX_PAQUETES = 50000   # tope en memoria; al llegar, la captura se detiene
IFACE_AUTO = "Automática (ruta por defecto)"
IFACES_VIRTUALES = ("docker", "veth", "br-", "virbr", "vmnet", "vboxnet",
                    "tun", "tap", "wg", "tailscale", "zt",
                    "ifb", "dummy", "sit", "gre", "nlmon")

PUERTOS_HTTP   = {80, 8000, 8008, 8080, 8888}
PUERTOS_DNS    = {53}
PUERTOS_DHCP   = {67, 68}
PUERTOS_DHCPV6 = {546, 547}
PUERTOS_NFS    = {2049, 111}   # 2049 = NFS, 111 = portmapper (rpcbind)

# Filtro BPF: lo aplica el kernel, así Python solo recibe lo que interesa.
# (HTTP/NFS se identifican por puerto; en "Todo el tráfico" además se detecta
#  HTTP por contenido aunque use un puerto distinto.)
BPF_POR_PROTOCOLO = {
    "HTTP": "tcp and (port 80 or port 8000 or port 8008 or port 8080 or port 8888)",
    "DNS":  "port 53",
    "DHCP": "udp and (port 67 or port 68 or port 546 or port 547)",
    "NFS":  "port 2049 or port 111",
}
PROTOCOLO_DEFECTO = "Todo el tráfico"
FILTROS_PROTOCOLO = {
    "Todo el tráfico":                None,
    "HTTP":                           {"HTTP"},
    "DNS":                            {"DNS"},
    "DHCP":                           {"DHCP"},
    "NFS":                            {"NFS"},
    "Los 4 (HTTP + DNS + DHCP + NFS)": {"HTTP", "DNS", "DHCP", "NFS"},
}


def bpf_para(apps):
    """Construye la expresión BPF para un conjunto de protocolos (None = sin filtro)."""
    if not apps:
        return None
    return " or ".join(f"({BPF_POR_PROTOCOLO[a]})" for a in sorted(apps))


# ============================================================
# --- Analizadores de protocolos de aplicación (capa 7)    ---
# ============================================================
_FLAGS_TCP = {"F": "FIN", "S": "SYN", "R": "RST", "P": "PSH",
              "A": "ACK", "U": "URG", "E": "ECE", "C": "CWR"}


def flags_tcp_texto(flags):
    """'SA' -> 'SYN, ACK'."""
    return ", ".join(_FLAGS_TCP.get(c, c) for c in str(flags)) or "-"


def _texto(valor):
    """Convierte bytes / listas de scapy en texto legible."""
    if isinstance(valor, bytes):
        try:
            return valor.decode("utf-8").rstrip("\x00")
        except UnicodeDecodeError:
            return valor.hex()
    if isinstance(valor, (list, tuple)):
        return ", ".join(_texto(v) for v in valor)
    return str(valor)


# ---------- HTTP ----------
_METODOS_HTTP = (b"GET ", b"POST ", b"PUT ", b"DELETE ", b"HEAD ",
                 b"OPTIONS ", b"PATCH ", b"CONNECT ", b"TRACE ")


def parse_http(payload):
    """Interpreta un segmento TCP como mensaje HTTP/1.x. Devuelve dict o None."""
    if not (payload.startswith(_METODOS_HTTP) or payload.startswith(b"HTTP/1.")):
        return None
    cabecera, _, cuerpo = payload.partition(b"\r\n\r\n")
    lineas = cabecera.decode("latin-1").split("\r\n")
    inicial = lineas[0]
    headers = []
    for linea in lineas[1:]:
        if ":" in linea:
            k, v = linea.split(":", 1)
            headers.append(("-".join(p.capitalize() for p in k.strip().split("-")), v.strip()))
    datos = {"inicial": inicial, "headers": headers, "cuerpo_bytes": len(cuerpo)}
    if payload.startswith(b"HTTP/1."):
        partes = inicial.split(" ", 2)
        datos.update(tipo="Respuesta", version=partes[0],
                     codigo=partes[1] if len(partes) > 1 else "",
                     mensaje=partes[2] if len(partes) > 2 else "")
    else:
        partes = inicial.split(" ")
        datos.update(tipo="Petición", metodo=partes[0],
                     uri=partes[1] if len(partes) > 1 else "",
                     version=partes[2] if len(partes) > 2 else "")
    return datos


def _info_http(h):
    cabeceras = dict(h["headers"])
    if h["tipo"] == "Petición":
        host = cabeceras.get("Host")
        return h["inicial"] + (f"  [Host: {host}]" if host else "")
    ct = cabeceras.get("Content-Type")
    return h["inicial"] + (f"  [{ct}]" if ct else "")


# ---------- NFS (ONC RPC) ----------
PROGRAMAS_RPC = {100000: "PORTMAP", 100003: "NFS", 100005: "MOUNT",
                 100021: "NLM", 100024: "STATUS"}
PROCS_NFS3 = {0: "NULL", 1: "GETATTR", 2: "SETATTR", 3: "LOOKUP", 4: "ACCESS",
              5: "READLINK", 6: "READ", 7: "WRITE", 8: "CREATE", 9: "MKDIR",
              10: "SYMLINK", 11: "MKNOD", 12: "REMOVE", 13: "RMDIR", 14: "RENAME",
              15: "LINK", 16: "READDIR", 17: "READDIRPLUS", 18: "FSSTAT",
              19: "FSINFO", 20: "PATHCONF", 21: "COMMIT"}
PROCS_NFS4 = {0: "NULL", 1: "COMPOUND"}
PROCS_PORTMAP = {0: "NULL", 1: "SET", 2: "UNSET", 3: "GETPORT", 4: "DUMP", 5: "CALLIT"}
PROCS_MOUNT = {0: "NULL", 1: "MNT", 2: "DUMP", 3: "UMNT", 4: "UMNTALL", 5: "EXPORT"}


def nombre_procedimiento_rpc(prog, vers, proc):
    if prog == 100003:
        tabla = PROCS_NFS4 if vers == 4 else PROCS_NFS3
    elif prog == 100000:
        tabla = PROCS_PORTMAP
    elif prog == 100005:
        tabla = PROCS_MOUNT
    else:
        tabla = {}
    return tabla.get(proc, str(proc))


def parse_rpc(payload, es_tcp):
    """Lee la cabecera ONC RPC (CALL o REPLY). Devuelve dict o None."""
    datos = payload
    if es_tcp:
        if len(datos) < 4:
            return None
        datos = datos[4:]          # RPC sobre TCP antepone un "record marker" de 4 bytes
    if len(datos) < 12:
        return None
    xid, tipo = struct.unpack("!II", datos[:8])
    if tipo == 0:                  # CALL
        if len(datos) < 24:
            return None
        rpcvers, prog, vers, proc = struct.unpack("!IIII", datos[8:24])
        if rpcvers != 2:
            return None
        return {"xid": xid, "tipo": "CALL", "rpcvers": rpcvers, "prog": prog,
                "vers": vers, "proc": proc,
                "prog_nombre": PROGRAMAS_RPC.get(prog, str(prog)),
                "proc_nombre": nombre_procedimiento_rpc(prog, vers, proc)}
    if tipo == 1:                  # REPLY
        estado = struct.unpack("!I", datos[8:12])[0]
        if estado not in (0, 1):
            return None
        return {"xid": xid, "tipo": "REPLY",
                "estado": "ACEPTADA" if estado == 0 else "RECHAZADA"}
    return None


def _info_rpc(rpc, rpc_calls):
    """Texto de resumen; guarda cada CALL para etiquetar su REPLY (mismo xid)."""
    if rpc["tipo"] == "CALL":
        if len(rpc_calls) > 5000:
            rpc_calls.clear()
        etiqueta = f"{rpc['prog_nombre']} v{rpc['vers']} {rpc['proc_nombre']}"
        rpc_calls[rpc["xid"]] = etiqueta
        return f"CALL {etiqueta}  (xid 0x{rpc['xid']:08x})"
    previa = rpc_calls.get(rpc["xid"], "?")
    return f"REPLY {previa}  (xid 0x{rpc['xid']:08x})  {rpc['estado'].lower()}"


# ---------- DNS ----------
TIPOS_DNS = {1: "A", 2: "NS", 5: "CNAME", 6: "SOA", 12: "PTR", 15: "MX", 16: "TXT",
             28: "AAAA", 33: "SRV", 65: "HTTPS", 255: "ANY"}
RCODES_DNS = {0: "NOERROR", 1: "FORMERR", 2: "SERVFAIL", 3: "NXDOMAIN",
              4: "NOTIMP", 5: "REFUSED"}


def _como_lista(campo, atributo, maximo):
    """Normaliza qd/an de scapy (según la versión: cadena de capas o lista)."""
    if campo is None:
        return []
    if isinstance(campo, Packet):
        items, actual = [], campo
        while (actual is not None and type(actual).__name__ != "NoPayload"
               and hasattr(actual, atributo) and len(items) < (maximo or 0)):
            items.append(actual)
            actual = actual.payload
        return items
    try:
        return [x for x in campo if hasattr(x, atributo)][:maximo or 0]
    except TypeError:
        return []


def dns_resumen(pkt):
    dns = pkt[DNS]
    preguntas = [(_texto(q.qname).rstrip("."), TIPOS_DNS.get(q.qtype, str(q.qtype)))
                 for q in _como_lista(dns.qd, "qname", dns.qdcount)]
    respuestas = [(_texto(rr.rrname).rstrip("."), TIPOS_DNS.get(rr.type, str(rr.type)),
                   _texto(getattr(rr, "rdata", "")), getattr(rr, "ttl", 0))
                  for rr in _como_lista(dns.an, "rrname", dns.ancount)]
    return {"id": dns.id, "qr": dns.qr, "opcode": dns.opcode, "rcode": dns.rcode,
            "aa": dns.aa, "tc": dns.tc, "rd": dns.rd, "ra": dns.ra,
            "preguntas": preguntas, "respuestas": respuestas}


def _info_dns(d):
    nombre, tipo = d["preguntas"][0] if d["preguntas"] else ("?", "?")
    if d["qr"] == 0:
        return f"Consulta {tipo} {nombre}"
    if d["rcode"] != 0:
        return f"Respuesta {tipo} {nombre} → {RCODES_DNS.get(d['rcode'], d['rcode'])}"
    if d["respuestas"]:
        valores = ", ".join(r[2] for r in d["respuestas"][:3])
        extra = " …" if len(d["respuestas"]) > 3 else ""
        return f"Respuesta {tipo} {nombre} → {valores}{extra}"
    return f"Respuesta {tipo} {nombre} (sin registros)"


# ---------- DHCP ----------
TIPOS_DHCP = {1: "Discover", 2: "Offer", 3: "Request", 4: "Decline",
              5: "ACK", 6: "NAK", 7: "Release", 8: "Inform"}
ETIQUETAS_OPCION_DHCP = {
    "requested_addr":    "Opción: IP solicitada",
    "server_id":         "Opción: Servidor DHCP (server_id)",
    "lease_time":        "Opción: Tiempo de arrendamiento",
    "subnet_mask":       "Opción: Máscara de subred",
    "router":            "Opción: Router (gateway)",
    "name_server":       "Opción: Servidores DNS",
    "hostname":          "Opción: Nombre de host",
    "domain":            "Opción: Dominio",
    "renewal_time":      "Opción: Tiempo T1 (renovación)",
    "rebinding_time":    "Opción: Tiempo T2 (reenlace)",
    "broadcast_address": "Opción: Dirección broadcast",
    "param_req_list":    "Opción: Parámetros solicitados",
    "client_id":         "Opción: Identificador de cliente",
    "vendor_class_id":   "Opción: Clase de proveedor",
}


def dhcp_resumen(pkt):
    b = pkt[BOOTP]
    chaddr = bytes(b.chaddr)[: (b.hlen or 6)]
    tipo = "BOOTP"
    opciones = []
    if pkt.haslayer(DHCP):
        for op in pkt[DHCP].options:
            if not isinstance(op, tuple):      # 'pad' / 'end'
                continue
            nombre, valores = op[0], op[1:]
            if nombre == "message-type":
                v = valores[0] if valores else None
                tipo = TIPOS_DHCP.get(v, str(v).capitalize()) if isinstance(v, int) else str(v).capitalize()
            elif nombre not in ("end", "pad"):
                opciones.append((nombre, ", ".join(_texto(v) for v in valores)))
    return {"op": b.op, "xid": b.xid, "ciaddr": b.ciaddr, "yiaddr": b.yiaddr,
            "siaddr": b.siaddr, "giaddr": b.giaddr,
            "chaddr": ":".join(f"{x:02x}" for x in chaddr),
            "tipo": tipo, "opciones": opciones}


def _info_dhcp(d):
    texto = f"{d['tipo']}  (xid 0x{d['xid']:08x})"
    if d["yiaddr"] not in ("0.0.0.0", "", None):
        texto += f"  IP asignada: {d['yiaddr']}"
    else:
        solicitada = dict(d["opciones"]).get("requested_addr")
        if solicitada:
            texto += f"  solicita: {solicitada}"
    return texto


# ---------- Clasificador general ----------
def clasificar_aplicacion(pkt, rpc_calls):
    """Devuelve (app, info). app ∈ {'HTTP','DNS','DHCP','NFS'} o None."""
    if pkt.haslayer(TCP):
        capa, es_tcp = pkt[TCP], True
    elif pkt.haslayer(UDP):
        capa, es_tcp = pkt[UDP], False
    else:
        return None, ""

    puertos = {capa.sport, capa.dport}
    flujo = f"{capa.sport} → {capa.dport}"
    sufijo = f"  [{flags_tcp_texto(capa.flags)}]" if es_tcp else ""
    base = f"{'TCP' if es_tcp else 'UDP'} {flujo}{sufijo}"
    # Solo Raw: así el relleno (Padding) de Ethernet no cuenta como datos
    payload = bytes(pkt[Raw].load) if pkt.haslayer(Raw) else b""

    # DHCP (UDP 67/68; DHCPv6 546/547)
    if pkt.haslayer(BOOTP):
        return "DHCP", _info_dhcp(dhcp_resumen(pkt))
    if not es_tcp and puertos & (PUERTOS_DHCP | PUERTOS_DHCPV6):
        return "DHCP", ("DHCPv6 " if puertos & PUERTOS_DHCPV6 else "") + flujo

    # DNS (puerto 53)
    if puertos & PUERTOS_DNS:
        if pkt.haslayer(DNS):
            return "DNS", _info_dns(dns_resumen(pkt))
        return "DNS", base

    # NFS: ONC RPC sobre 2049 / 111
    if puertos & PUERTOS_NFS:
        rpc = parse_rpc(payload, es_tcp)
        return "NFS", (_info_rpc(rpc, rpc_calls) if rpc else base)

    # HTTP: por contenido (cualquier puerto) o por puerto conocido
    if es_tcp:
        http = parse_http(payload)
        if http:
            return "HTTP", _info_http(http)
        if puertos & PUERTOS_HTTP:
            return "HTTP", (f"Datos {flujo}{sufijo}  ({len(payload)} bytes)" if payload else base)

    return None, ""


# ---------- ICMPv4 / ICMPv6 ----------
TIPOS_ICMP4 = {0: "Echo reply", 3: "Destino inalcanzable", 4: "Source quench", 5: "Redirección",
               8: "Echo request", 9: "Router advertisement", 10: "Router solicitation",
               11: "Tiempo excedido", 12: "Problema de parámetros", 13: "Timestamp request",
               14: "Timestamp reply", 17: "Address mask request", 18: "Address mask reply"}
CODIGOS_ICMP4 = {
    3:  {0: "red inalcanzable", 1: "host inalcanzable", 2: "protocolo inalcanzable",
         3: "puerto inalcanzable", 4: "requiere fragmentar (DF activo)", 5: "falló la ruta de origen",
         13: "filtrado administrativamente"},
    5:  {0: "para la red", 1: "para el host", 2: "para ToS y red", 3: "para ToS y host"},
    11: {0: "TTL excedido en tránsito", 1: "tiempo de reensamblado excedido"},
}
TIPOS_ICMP6 = {1: "Destino inalcanzable", 2: "Paquete demasiado grande", 3: "Tiempo excedido",
               4: "Problema de parámetros", 128: "Echo request", 129: "Echo reply",
               130: "MLD Query", 131: "MLDv1 Report", 132: "MLD Done",
               133: "Router Solicitation (RS)", 134: "Router Advertisement (RA)",
               135: "Neighbor Solicitation (NS)", 136: "Neighbor Advertisement (NA)",
               137: "Redirect", 143: "MLDv2 Report"}
CODIGOS_ICMP6 = {
    1: {0: "sin ruta al destino", 1: "comunicación prohibida administrativamente",
        2: "fuera del alcance de la dirección origen", 3: "dirección inalcanzable",
        4: "puerto inalcanzable"},
    3: {0: "límite de saltos excedido", 1: "tiempo de reensamblado excedido"},
    4: {0: "campo de encabezado erróneo", 1: "Next Header desconocido", 2: "opción IPv6 desconocida"},
}


def _hex(valor):
    return hex(valor) if isinstance(valor, int) else "-"


def icmp4_resumen(pkt):
    """Interpreta el mensaje ICMPv4. Devuelve dict con tipo, código, checksum y filas extra."""
    i = pkt[ICMP]
    tipo, codigo = int(i.type), int(i.code)
    extra = []
    if tipo in (0, 8, 13, 14, 17, 18):
        extra += [("Identificador", i.id), ("Secuencia", i.seq)]
    if tipo == 5 and hasattr(i, "gw"):
        extra.append(("Gateway (redirección)", i.gw))
    if tipo == 3 and codigo == 4 and getattr(i, "nexthopmtu", None):
        extra.append(("MTU del siguiente salto", f"{i.nexthopmtu} bytes"))
    if tipo in (3, 4, 5, 11, 12) and pkt.haslayer(IPerror):
        e = pkt[IPerror]
        orig = f"{e.src} → {e.dst}  (protocolo {e.proto})"
        if pkt.haslayer(TCPerror):
            orig += f"  TCP {pkt[TCPerror].sport} → {pkt[TCPerror].dport}"
        elif pkt.haslayer(UDPerror):
            orig += f"  UDP {pkt[UDPerror].sport} → {pkt[UDPerror].dport}"
        extra.append(("Paquete original citado", orig))
    return {"tipo": tipo, "codigo": codigo, "cksum": i.chksum,
            "nombre": TIPOS_ICMP4.get(tipo, f"Tipo {tipo}"),
            "codigo_texto": CODIGOS_ICMP4.get(tipo, {}).get(codigo),
            "extra": extra}


def obtener_icmpv6(pkt):
    """Busca el mensaje ICMPv6 aunque haya cabeceras de extensión (p. ej. Hop-by-Hop en MLD)."""
    capa = pkt.getlayer(IPv6)
    capa = capa.payload if capa is not None else None
    while capa is not None and not isinstance(capa, NoPayload):
        nombre = capa.__class__.__name__
        if nombre.startswith("ICMPv6") and not nombre.startswith("ICMPv6NDOpt"):
            return capa
        capa = capa.payload
    return None


def _lladdr_opcion(msg):
    """MAC anunciada en las opciones de Neighbor Discovery (Source/Target Link-Layer Address)."""
    capa = msg.payload
    while capa is not None and not isinstance(capa, NoPayload):
        if hasattr(capa, "lladdr"):
            return capa.lladdr
        capa = capa.payload
    return None


def icmp6_resumen(pkt):
    """Interpreta el mensaje ICMPv6. Devuelve dict o None si el paquete no lo contiene."""
    m = obtener_icmpv6(pkt)
    if m is None:
        return None
    tipo, codigo = int(m.type), int(getattr(m, "code", 0))
    extra = []
    mac = _lladdr_opcion(m)
    if tipo in (128, 129):
        extra += [("Identificador", m.id), ("Secuencia", m.seq)]
    elif tipo in (135, 136, 137):
        extra.append(("Dirección objetivo (tgt)", m.tgt))
        if tipo == 136:
            extra.append(("Flags NA (R/S/O)", f"R={m.R} S={m.S} O={m.O}"))
        if tipo == 137:
            extra.append(("Dirección destino (dst)", m.dst))
    elif tipo == 134:
        extra += [("Hop limit anunciado", m.chlim),
                  ("Flags RA (M/O)", f"M={m.M} O={m.O}"),
                  ("Vida del router (s)", m.routerlifetime)]
    elif tipo == 2 and hasattr(m, "mtu"):
        extra.append(("MTU", f"{m.mtu} bytes"))
    elif tipo == 4 and hasattr(m, "ptr"):
        extra.append(("Puntero al error", m.ptr))
    if mac:
        extra.append(("Dirección MAC (opción)", mac))
    return {"tipo": tipo, "codigo": codigo, "cksum": getattr(m, "cksum", None),
            "nombre": TIPOS_ICMP6.get(tipo, f"Tipo {tipo}"),
            "codigo_texto": CODIGOS_ICMP6.get(tipo, {}).get(codigo),
            "extra": extra, "mac": mac, "msg": m}


def _info_icmp4(d):
    txt = d["nombre"]
    if d["codigo_texto"]:
        txt += f": {d['codigo_texto']}"
    ex = dict(d["extra"])
    if "Identificador" in ex:
        txt += f"  (id={ex['Identificador']}, seq={ex['Secuencia']})"
    return txt


def _info_icmp6(d):
    ex, tipo = dict(d["extra"]), d["tipo"]
    if tipo == 135:
        return f"Neighbor Solicitation: ¿quién tiene {ex['Dirección objetivo (tgt)']}?"
    if tipo == 136:
        donde = f" está en {d['mac']}" if d["mac"] else " (anuncio)"
        return f"Neighbor Advertisement: {ex['Dirección objetivo (tgt)']}{donde}"
    if tipo == 133:
        return "Router Solicitation: busco un router"
    if tipo == 134:
        return f"Router Advertisement (vida {ex['Vida del router (s)']} s)"
    txt = d["nombre"]
    if d["codigo_texto"]:
        txt += f": {d['codigo_texto']}"
    if "Identificador" in ex:
        txt += f"  (id={ex['Identificador']}, seq={ex['Secuencia']})"
    return txt


DICCIONARIO_ICMP = {}
for _v, _t in (("ICMPv4", "ICMPv4"), ("ICMPv6", "ICMPv6")):
    DICCIONARIO_ICMP[f"{_v} Tipo"] = ("Clase de mensaje de control. " + (
        "ICMPv4: 0 Echo reply, 3 Destino inalcanzable, 5 Redirección, 8 Echo request (ping), 11 Tiempo excedido."
        if _v == "ICMPv4" else
        "ICMPv6: 1 Destino inalcanzable, 3 Tiempo excedido, 128/129 Echo request/reply, 133-137 Neighbor Discovery (RS, RA, NS, NA, Redirect)."))
    DICCIONARIO_ICMP[f"{_v} Código"] = "Subtipo que precisa el motivo del mensaje (por ejemplo, en Destino inalcanzable indica si falló la red, el host o el puerto)."
    DICCIONARIO_ICMP[f"{_v} Checksum"] = "Suma de verificación que protege el mensaje ICMP. " + (
        "En ICMPv6 además cubre un pseudo-encabezado con las IPv6 de origen y destino." if _v == "ICMPv6" else "")
    DICCIONARIO_ICMP[f"{_v} Identificador"] = "Número que identifica la sesión de ping; la respuesta (Echo reply) lo repite."
    DICCIONARIO_ICMP[f"{_v} Secuencia"] = "Contador que aumenta con cada Echo request; sirve para emparejar respuestas y detectar pérdidas."
DICCIONARIO_ICMP.update({
    "ICMPv4 Gateway (redirección)": "Router mejor ubicado al que el emisor debe enviar el tráfico hacia ese destino (mensaje Redirect).",
    "ICMPv4 MTU del siguiente salto": "Tamaño máximo de paquete que admite el siguiente enlace; se informa cuando se necesita fragmentar y el bit DF está activo (Path MTU Discovery).",
    "ICMPv4 Paquete original citado": "Los mensajes de error incluyen la cabecera del paquete que provocó el error; aquí se muestra su origen, destino y puertos.",
    "ICMPv6 Dirección objetivo (tgt)": "Dirección IPv6 cuya MAC se pregunta (NS) o se anuncia (NA). Equivale a la IP consultada en un ARP de IPv4.",
    "ICMPv6 Flags NA (R/S/O)": "R = el emisor es un router, S = respuesta a una solicitud (Solicited), O = sobrescribe la entrada de caché del vecino (Override).",
    "ICMPv6 Dirección destino (dst)": "En un Redirect, dirección final del destino al que se refiere la redirección.",
    "ICMPv6 Hop limit anunciado": "Valor de Hop Limit que el router recomienda usar a los hosts de la red.",
    "ICMPv6 Flags RA (M/O)": "M = las direcciones se obtienen por DHCPv6 (Managed); O = solo otra información (DNS, etc.) por DHCPv6 (Other).",
    "ICMPv6 Vida del router (s)": "Segundos durante los que el emisor puede usarse como router predeterminado; 0 significa que deja de serlo.",
    "ICMPv6 MTU": "MTU del enlace que no pudo reenviar el paquete (mensaje Paquete demasiado grande).",
    "ICMPv6 Puntero al error": "Posición (en bytes) dentro del paquete original donde se detectó el problema.",
    "ICMPv6 Dirección MAC (opción)": "Opción de Neighbor Discovery con la dirección física del emisor o del objetivo; sustituye a la respuesta ARP de IPv4.",
})


def info_generica(pkt):
    """Resumen de una línea para paquetes que no son de capa 7 conocida."""
    if pkt.haslayer(ARP):
        a = pkt[ARP]
        if a.op == 1:
            return f"¿Quién tiene {a.pdst}? Dile a {a.psrc}"
        if a.op == 2:
            return f"{a.psrc} está en {a.hwsrc}"
        return f"ARP op {a.op}"
    if pkt.haslayer(ICMP):                      # ICMP antes que TCP/UDP: los errores citan el paquete original
        return _info_icmp4(icmp4_resumen(pkt))
    if pkt.haslayer(IPv6):
        d6 = icmp6_resumen(pkt)
        if d6:
            return _info_icmp6(d6)
    if pkt.haslayer(TCP):
        t = pkt[TCP]
        return f"{t.sport} → {t.dport}  [{flags_tcp_texto(t.flags)}]"
    if pkt.haslayer(UDP):
        u = pkt[UDP]
        return f"{u.sport} → {u.dport}  len={u.len}"
    return ""


class AnimatedButton(tk.Canvas):
    def __init__(self, parent, text, command=None, color=None, width=150, height=34, **kwargs):
        super().__init__(parent, width=width, height=height,
                         bg=COLORS["bg_surface"], highlightthickness=0, bd=0)
        self.command = command
        self.color = color or COLORS["accent_cyan"]
        self.text = text
        self.w = width
        self.h = height
        self._disabled = False
        self._draw(hover=False)
        self.bind("<Enter>",    lambda e: self._draw(hover=True)  if not self._disabled else None)
        self.bind("<Leave>",    lambda e: self._draw(hover=False) if not self._disabled else None)
        self.bind("<Button-1>", lambda e: self._click())

    def _draw(self, hover=False):
        self.delete("all")
        r = 4
        w, h = self.w, self.h
        bg = COLORS["bg_hover"] if hover else COLORS["bg_elevated"]
        bc = self.color if hover and not self._disabled else (COLORS["border_dim"] if self._disabled else COLORS["border_mid"])
        self.create_rectangle(1, 1, w-1, h-1, outline=bc, fill=bg, width=1)
        if not self._disabled:
            self.create_line(r, 1, w-r, 1, fill=bc if not hover else self.color, width=1)
        fc = self.color if not self._disabled else COLORS["text_dim"]
        self.create_text(w//2, h//2, text=self.text, fill=fc, font=("Consolas", 9, "bold"), anchor="center")

    def _click(self):
        if not self._disabled and self.command:
            self.command()

    def config_state(self, state):
        self._disabled = (state == tk.DISABLED)
        self._draw(hover=False)

    def configure(self, **kwargs):
        if "state" in kwargs:
            self.config_state(kwargs.pop("state"))
        super().configure(**kwargs)


class StatusBadge(tk.Canvas):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, width=12, height=12, bg=COLORS["bg_base"], highlightthickness=0, bd=0)
        self._active = False
        self._phase = 0
        self._draw()

    def _draw(self):
        self.delete("all")
        color = COLORS["accent_green"] if self._active else COLORS["text_dim"]
        if self._active:
            outer_r = 5 + int(self._phase * 1.5)
            alpha_colors = ["#004422", "#002211", "#001108"]
            if outer_r <= 6:
                self.create_oval(6-outer_r, 6-outer_r, 6+outer_r, 6+outer_r, outline=alpha_colors[min(outer_r-5, 2)], fill="")
        self.create_oval(3, 3, 9, 9, fill=color, outline="")

    def set_active(self, active):
        self._active = active
        if active:
            self._animate()
        else:
            self._phase = 0
            self._draw()

    def _animate(self):
        if not self._active:
            return
        self._phase = (self._phase + 1) % 4
        self._draw()
        self.after(400, self._animate)


class PacketCounter(tk.Frame):
    def __init__(self, parent, label, color, **kwargs):
        super().__init__(parent, bg=COLORS["bg_surface"], **kwargs)
        tk.Label(self, text=label, bg=COLORS["bg_surface"], fg=COLORS["text_secondary"], font=("Consolas", 8, "normal")).pack(anchor="w")
        self.count_var = tk.StringVar(value="0")
        tk.Label(self, textvariable=self.count_var, bg=COLORS["bg_surface"], fg=color, font=("Consolas", 16, "bold")).pack(anchor="w")
        self._count = 0

    def increment(self):
        self._count += 1
        self.count_var.set(str(self._count))

    def reset(self):
        self._count = 0
        self.count_var.set("0")


class SectionHeader(tk.Frame):
    def __init__(self, parent, title, icon="", accent=None, **kwargs):
        super().__init__(parent, bg=COLORS["bg_card"], **kwargs)
        accent = accent or COLORS["accent_cyan"]
        tk.Frame(self, bg=accent, width=2).pack(side=tk.LEFT, fill=tk.Y, padx=(0, 8))
        tk.Label(self, text=f"{icon}  {title}" if icon else title, bg=COLORS["bg_card"], fg=accent, font=("Consolas", 9, "bold")).pack(side=tk.LEFT, pady=6)
        line = tk.Frame(self, bg=COLORS["border_dim"], height=1)
        line.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=10)


class SnifferApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Sniffer Global de Red")
        self.root.configure(bg=COLORS["bg_base"])
        self.root.minsize(1024, 650) # Límitador mínimo para evitar colapsos visuales extremos

        # --- AJUSTE CLAVE: MAXIMIZAR AUTOMÁTICAMENTE DEPENDIENDO DEL S.O ---
        try:
            if platform.system() == "Linux" or platform.system() == "Darwin":
                self.root.attributes('-zoomed', True)
            else:
                self.root.state('zoomed')
        except:
            self.root.geometry("1280x750") # Fallback seguro por si falla la llamada nativa

        self.paquetes = []
        self.sniffing = False
        self.current_interface = None
        self.pkt_counts = {"TCP": 0, "UDP": 0, "ICMP": 0, "ARP": 0, "Otro": 0}

        # --- Estado de captura y filtros (v2.2) ---
        self.iface_auto = True                  # True = tarjeta elegida automáticamente
        self.iface_map = {}                     # etiqueta del combo -> nombre real de interfaz
        self._etiqueta_iface_actual = IFACE_AUTO
        self.apps_filtro = FILTROS_PROTOCOLO[PROTOCOLO_DEFECTO]   # None = todo el tráfico
        self.sniffer = None                     # AsyncSniffer activo
        self.cola = queue.Queue(maxsize=20000)  # hilo de captura -> hilo de la GUI
        self.rpc_calls = {}                     # xid -> llamada RPC (para emparejar respuestas NFS)

        self.diccionario_campos = self.inicializar_diccionario()
        self._setup_styles()
        self._build_ui()

        self.refresh_interface()
        self.start_network_monitor()
        self.root.after(100, self._drain_queue)

    def _setup_styles(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure(".", background=COLORS["bg_base"], foreground=COLORS["text_primary"], borderwidth=0)
        s.configure("Packets.Treeview", background=COLORS["bg_card"], foreground=COLORS["text_primary"], fieldbackground=COLORS["bg_card"], borderwidth=0, rowheight=24, font=("Consolas", 9))
        s.configure("Packets.Treeview.Heading", background=COLORS["bg_elevated"], foreground=COLORS["accent_cyan"], font=("Consolas", 9, "bold"), relief="flat", borderwidth=0)
        s.map("Packets.Treeview", background=[("selected", COLORS["bg_hover"])], foreground=[("selected", COLORS["accent_cyan"])])
        s.configure("Details.Treeview", background=COLORS["bg_surface"], foreground=COLORS["text_mono"], fieldbackground=COLORS["bg_surface"], borderwidth=0, rowheight=22, font=("Consolas", 9))
        s.configure("Details.Treeview.Heading", background=COLORS["bg_elevated"], foreground=COLORS["accent_green"], font=("Consolas", 9, "bold"), relief="flat")
        s.map("Details.Treeview", background=[("selected", COLORS["bg_hover"])], foreground=[("selected", COLORS["accent_green"])])
        s.configure("Dark.Vertical.TScrollbar", background=COLORS["bg_elevated"], troughcolor=COLORS["bg_card"], borderwidth=0, arrowsize=10)
        s.configure("Dark.TSeparator", background=COLORS["border_dim"])
        s.configure("Dark.Horizontal.TScrollbar", background=COLORS["bg_elevated"], troughcolor=COLORS["bg_card"], borderwidth=0, arrowsize=10)

        # Desplegables (Combobox) con estética oscura
        s.configure("Dark.TCombobox", fieldbackground=COLORS["bg_elevated"], background=COLORS["bg_hover"],
                    foreground=COLORS["text_primary"], arrowcolor=COLORS["accent_cyan"],
                    bordercolor=COLORS["border_mid"], lightcolor=COLORS["border_mid"], darkcolor=COLORS["border_mid"],
                    selectbackground=COLORS["bg_elevated"], selectforeground=COLORS["text_primary"], padding=3)
        s.map("Dark.TCombobox",
              fieldbackground=[("readonly", COLORS["bg_elevated"])],
              foreground=[("readonly", COLORS["text_primary"])],
              selectbackground=[("readonly", COLORS["bg_elevated"])],
              selectforeground=[("readonly", COLORS["text_primary"])],
              bordercolor=[("focus", COLORS["accent_cyan"])])
        # La lista desplegable es un Listbox de Tk: se colorea con option_add
        self.root.option_add("*TCombobox*Listbox.background", COLORS["bg_elevated"])
        self.root.option_add("*TCombobox*Listbox.foreground", COLORS["text_primary"])
        self.root.option_add("*TCombobox*Listbox.selectBackground", COLORS["bg_hover"])
        self.root.option_add("*TCombobox*Listbox.selectForeground", COLORS["accent_cyan"])
        self.root.option_add("*TCombobox*Listbox.font", ("Consolas", 9))

    def _build_ui(self):
        # Se configura la raíz (root) como un grid dinámico escalable
        self.root.rowconfigure(5, weight=1)  # Solo los paneles principales (fila 5) se estiran; la barra de red (fila 4) no
        self.root.columnconfigure(0, weight=1)

        self._build_titlebar()
        self._build_toolbar()
        self._build_stats_bar()
        self._build_network_bar()
        self._build_main_panels()
        self._build_statusbar()

    def _build_titlebar(self):
        bar = tk.Frame(self.root, bg=COLORS["bg_base"], height=40)
        bar.grid(row=0, column=0, sticky="ew")
        bar.pack_propagate(False)
        
        tk.Label(bar, text="◈", bg=COLORS["bg_base"], fg=COLORS["accent_cyan"], font=("Consolas", 14)).pack(side=tk.LEFT, padx=(15, 4))
        tk.Label(bar, text="Sniffer Global de Red by Pandinux 19", bg=COLORS["bg_base"], fg=COLORS["text_primary"], font=("Consolas", 12, "bold")).pack(side=tk.LEFT)
        tk.Label(bar, text="  //  Analizador de Red: HTTP · DNS · DHCP · NFS", bg=COLORS["bg_base"], fg=COLORS["text_dim"], font=("Consolas", 9)).pack(side=tk.LEFT, padx=4)

        right = tk.Frame(bar, bg=COLORS["bg_base"])
        right.pack(side=tk.RIGHT, padx=15)
        self.status_badge = StatusBadge(right)
        self.status_badge.pack(side=tk.LEFT, padx=(0, 6))
        self.status_label_top = tk.Label(right, text="INACTIVO", bg=COLORS["bg_base"], fg=COLORS["text_dim"], font=("Consolas", 9, "bold"))
        self.status_label_top.pack(side=tk.LEFT)
        
        tk.Frame(self.root, bg=COLORS["border_dim"], height=1).grid(row=1, column=0, sticky="ew")

    def _build_toolbar(self):
        bar = tk.Frame(self.root, bg=COLORS["bg_surface"], pady=6, padx=15)
        bar.grid(row=2, column=0, sticky="ew")

        # --- Fila 1: botones de acción ---
        fila_botones = tk.Frame(bar, bg=COLORS["bg_surface"])
        fila_botones.pack(fill=tk.X)

        self.start_btn = AnimatedButton(fila_botones, "▶  INICIAR CAPTURA", command=self.start_sniffing, color=COLORS["accent_green"], width=150, height=32)
        self.start_btn.pack(side=tk.LEFT, padx=(0, 6))

        self.stop_btn = AnimatedButton(fila_botones, "■  DETENER", command=self.stop_sniffing, color=COLORS["accent_red"], width=120, height=32)
        self.stop_btn.pack(side=tk.LEFT, padx=(0, 6))
        self.stop_btn.config_state(tk.DISABLED)

        self.clear_btn = AnimatedButton(fila_botones, "⊘  LIMPIAR DATOS", command=self.limpiar_tabla, color=COLORS["accent_amber"], width=130, height=32)
        self.clear_btn.pack(side=tk.LEFT, padx=(0, 15))

        self.refresh_btn = AnimatedButton(fila_botones, "↻  REFRESCAR RED", command=self.refresh_interface, color=COLORS["accent_blue"], width=150, height=32)
        self.refresh_btn.pack(side=tk.LEFT)

        # --- Fila 2: selectores de tarjeta y de protocolo ---
        fila_sel = tk.Frame(bar, bg=COLORS["bg_surface"])
        fila_sel.pack(fill=tk.X, pady=(8, 0))

        tk.Label(fila_sel, text="TARJETA DE RED:", bg=COLORS["bg_surface"], fg=COLORS["text_secondary"], font=("Consolas", 9, "bold")).pack(side=tk.LEFT, padx=(0, 6))
        self.combo_iface = ttk.Combobox(fila_sel, state="readonly", width=46, style="Dark.TCombobox", font=("Consolas", 9))
        self.combo_iface.pack(side=tk.LEFT, padx=(0, 25))
        self.combo_iface.bind("<<ComboboxSelected>>", self.on_cambio_interfaz)

        tk.Label(fila_sel, text="PROTOCOLO:", bg=COLORS["bg_surface"], fg=COLORS["text_secondary"], font=("Consolas", 9, "bold")).pack(side=tk.LEFT, padx=(0, 6))
        self.combo_proto = ttk.Combobox(fila_sel, state="readonly", width=30, style="Dark.TCombobox",
                                        font=("Consolas", 9), values=list(FILTROS_PROTOCOLO))
        self.combo_proto.set(PROTOCOLO_DEFECTO)
        self.combo_proto.pack(side=tk.LEFT)
        self.combo_proto.bind("<<ComboboxSelected>>", self.on_cambio_protocolo)

    def _build_stats_bar(self):
        bar = tk.Frame(self.root, bg=COLORS["bg_surface"], pady=6, padx=15)
        bar.grid(row=3, column=0, sticky="ew")

        self.counter_total = PacketCounter(bar, "TOTAL CAPTURADOS", COLORS["text_primary"])
        self.counter_total.pack(side=tk.LEFT, padx=(0, 20))
        tk.Frame(bar, bg=COLORS["border_dim"], width=1).pack(side=tk.LEFT, fill=tk.Y, pady=2, padx=(0, 20))

        self.counter_tcp   = PacketCounter(bar, "TCP",   COLORS["proto_tcp"])
        self.counter_tcp.pack(side=tk.LEFT, padx=(0, 20))
        self.counter_udp   = PacketCounter(bar, "UDP",   COLORS["proto_udp"])
        self.counter_udp.pack(side=tk.LEFT, padx=(0, 20))
        self.counter_icmp  = PacketCounter(bar, "ICMP/v6",  COLORS["proto_icmp"])
        self.counter_icmp.pack(side=tk.LEFT, padx=(0, 20))
        self.counter_arp   = PacketCounter(bar, "ARP",   COLORS["proto_arp"])
        self.counter_arp.pack(side=tk.LEFT, padx=(0, 20))
        self.counter_other = PacketCounter(bar, "OTROS", COLORS["proto_other"])
        self.counter_other.pack(side=tk.LEFT, padx=(0, 20))

        # Contadores de capa 7 (cuentan además del protocolo de transporte)
        tk.Frame(bar, bg=COLORS["border_dim"], width=1).pack(side=tk.LEFT, fill=tk.Y, pady=2, padx=(0, 20))
        self.counter_http = PacketCounter(bar, "HTTP", COLORS["proto_http"])
        self.counter_http.pack(side=tk.LEFT, padx=(0, 20))
        self.counter_dns  = PacketCounter(bar, "DNS",  COLORS["proto_dns"])
        self.counter_dns.pack(side=tk.LEFT, padx=(0, 20))
        self.counter_dhcp = PacketCounter(bar, "DHCP", COLORS["proto_dhcp"])
        self.counter_dhcp.pack(side=tk.LEFT, padx=(0, 20))
        self.counter_nfs  = PacketCounter(bar, "NFS",  COLORS["proto_nfs"])
        self.counter_nfs.pack(side=tk.LEFT)
        self.contadores_app = {"HTTP": self.counter_http, "DNS": self.counter_dns,
                               "DHCP": self.counter_dhcp, "NFS": self.counter_nfs}

        self.time_label = tk.Label(bar, text="", bg=COLORS["bg_surface"], fg=COLORS["text_dim"], font=("Consolas", 8))
        self.time_label.pack(side=tk.RIGHT, padx=4)
        self._update_clock()

    def _build_network_bar(self):
        # Se usa Grid dinámico interno para la banda de información técnica
        bar = tk.Frame(self.root, bg=COLORS["bg_elevated"], pady=5, padx=15)
        bar.grid(row=4, column=0, sticky="ew")
        
        for i in range(6): bar.columnconfigure(i, weight=1)

        def net_grid_item(parent, key, col, color_val=None):
            f = tk.Frame(parent, bg=COLORS["bg_elevated"])
            f.grid(row=0, column=col, sticky="w")
            tk.Label(f, text=key, bg=COLORS["bg_elevated"], fg=COLORS["text_dim"], font=("Consolas", 8, "bold")).pack(side=tk.LEFT, padx=(0, 5))
            var = tk.StringVar(value="--")
            tk.Label(f, textvariable=var, bg=COLORS["bg_elevated"], fg=color_val or COLORS["text_primary"], font=("Consolas", 9)).pack(side=tk.LEFT)
            return var

        self.net_iface_var = net_grid_item(bar, "INTERFAZ", 0, COLORS["accent_cyan"])
        self.net_type_var  = net_grid_item(bar, "TIPO",     1, COLORS["text_secondary"])
        self.net_ipv4_var  = net_grid_item(bar, "IPv4",     2, COLORS["accent_green"])
        self.net_ipv6_var  = net_grid_item(bar, "IPv6",     3, COLORS["text_mono"])
        self.net_mac_var   = net_grid_item(bar, "MAC",      4, COLORS["text_secondary"])
        self.net_ssid_var  = net_grid_item(bar, "RED",      5, COLORS["accent_amber"])

    def _update_clock(self):
        self.time_label.config(text=time.strftime("  %Y-%m-%d  %H:%M:%S  "))
        self.root.after(1000, self._update_clock)

    def _build_main_panels(self):
        # Este contenedor ocupará todo el centro variable de la pantalla
        main = tk.Frame(self.root, bg=COLORS["bg_base"])
        main.grid(row=5, column=0, sticky="nsew") 
        self.root.rowconfigure(5, weight=1) # Le da el verdadero peso elástico vertical

        self.main_splitter = tk.PanedWindow(main, orient=tk.HORIZONTAL, bg=COLORS["bg_base"], sashwidth=4, sashrelief=tk.FLAT, sashpad=0)
        self.main_splitter.pack(fill=tk.BOTH, expand=True, padx=6, pady=(6, 0))

        # --- PANEL IZQUIERDO ---
        left = tk.Frame(self.main_splitter, bg=COLORS["bg_card"])
        SectionHeader(left, "TRÁFICO INTERCEPTADO EN TIEMPO REAL", "⬡").pack(fill=tk.X)

        tree_frame = tk.Frame(left, bg=COLORS["bg_card"])
        tree_frame.pack(fill=tk.BOTH, expand=True)

        columns = ("ID", "Protocolo", "MAC Origen", "MAC Destino", "IP Origen", "IP Destino", "Info")
        self.tree_lista = ttk.Treeview(tree_frame, columns=columns, show="headings", style="Packets.Treeview", selectmode="browse")

        # Configuración elástica de anchos de columna (stretch=True)
        col_cfg = {
            "ID": (45, tk.CENTER), 
            "Protocolo": (75, tk.CENTER),
            "MAC Origen": (120, tk.W), 
            "MAC Destino": (120, tk.W),
            "IP Origen": (125, tk.W), 
            "IP Destino": (125, tk.W),
            "Info": (280, tk.W)
        }
        for col, (w, anchor) in col_cfg.items():
            self.tree_lista.heading(col, text=col)
            self.tree_lista.column(col, width=w, anchor=anchor, minwidth=w, stretch=True)

        self.tree_lista.tag_configure("TCP",  foreground=COLORS["proto_tcp"])
        self.tree_lista.tag_configure("UDP",  foreground=COLORS["proto_udp"])
        self.tree_lista.tag_configure("ICMP", foreground=COLORS["proto_icmp"])
        self.tree_lista.tag_configure("ICMPv6", foreground=COLORS["proto_icmp"])
        self.tree_lista.tag_configure("ARP",  foreground=COLORS["proto_arp"])
        self.tree_lista.tag_configure("Otro", foreground=COLORS["proto_other"])
        self.tree_lista.tag_configure("HTTP", foreground=COLORS["proto_http"])
        self.tree_lista.tag_configure("DNS",  foreground=COLORS["proto_dns"])
        self.tree_lista.tag_configure("DHCP", foreground=COLORS["proto_dhcp"])
        self.tree_lista.tag_configure("NFS",  foreground=COLORS["proto_nfs"])
        self.tree_lista.tag_configure("even", background=COLORS["bg_surface"])
        self.tree_lista.tag_configure("odd",  background=COLORS["bg_card"])

        scroll_h = ttk.Scrollbar(tree_frame, orient=tk.HORIZONTAL, command=self.tree_lista.xview, style="Dark.Horizontal.TScrollbar")
        scroll_v = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree_lista.yview, style="Dark.Vertical.TScrollbar")
        self.tree_lista.configure(yscroll=scroll_v.set, xscroll=scroll_h.set)
        scroll_h.pack(side=tk.BOTTOM, fill=tk.X)
        scroll_v.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree_lista.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.tree_lista.bind("<<TreeviewSelect>>", self.cargar_capas_paquete)

        # --- PANEL DERECHO (SPLITTER VERTICAL RESPONSIVO) ---
        right = tk.PanedWindow(self.main_splitter, orient=tk.VERTICAL, bg=COLORS["bg_base"], sashwidth=4, sashrelief=tk.FLAT, sashpad=0)

        top_right = tk.Frame(right, bg=COLORS["bg_surface"])
        SectionHeader(top_right, "ESTRUCTURA COMPLETA DEL DATAGRAMA", "⬡", accent=COLORS["accent_green"]).pack(fill=tk.X)

        detail_frame = tk.Frame(top_right, bg=COLORS["bg_surface"])
        detail_frame.pack(fill=tk.BOTH, expand=True)

        self.tree_detalles = ttk.Treeview(detail_frame, columns=("Valor",), show="tree headings", style="Details.Treeview")
        self.tree_detalles.heading("#0",    text="CAMPO / SEGMENTO")
        self.tree_detalles.heading("Valor", text="VALOR INTERPRETADO")
        self.tree_detalles.column("#0",    width=200, anchor=tk.W, minwidth=140, stretch=True)
        self.tree_detalles.column("Valor", width=200, anchor=tk.W, minwidth=120, stretch=True)

        scroll_det = ttk.Scrollbar(detail_frame, orient=tk.VERTICAL, command=self.tree_detalles.yview, style="Dark.Vertical.TScrollbar")
        self.tree_detalles.configure(yscroll=scroll_det.set)
        self.tree_detalles.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll_det.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree_detalles.bind("<<TreeviewSelect>>", self.inspeccionar_campo)

        bottom_right = tk.Frame(right, bg=COLORS["bg_base"])
        SectionHeader(bottom_right, "INSPECTOR TEÓRICO DE CAMPO", "⬡", accent=COLORS["accent_amber"]).pack(fill=tk.X)

        self.inspector_text = tk.Text(bottom_right, bg=COLORS["bg_surface"], fg=COLORS["text_primary"], font=("Consolas", 9), wrap=tk.WORD, borderwidth=0, insertbackground=COLORS["accent_cyan"], selectbackground=COLORS["bg_hover"], relief="flat", padx=10, pady=8)
        self.inspector_text.pack(fill=tk.BOTH, expand=True, padx=2, pady=(0, 2))

        self.inspector_text.tag_configure("header", foreground=COLORS["accent_amber"], font=("Consolas", 10, "bold"))
        self.inspector_text.tag_configure("value", foreground=COLORS["accent_cyan"], font=("Consolas", 9))
        self.inspector_text.tag_configure("label", foreground=COLORS["text_secondary"], font=("Consolas", 9, "bold"))
        self.inspector_text.tag_configure("body", foreground=COLORS["text_primary"], font=("Consolas", 9))
        self.inspector_text.tag_configure("dim", foreground=COLORS["text_dim"], font=("Consolas", 9))

        # Añadimos los elementos calculando pesos proporcionales (50% - 50%)
        self.main_splitter.add(left,  minsize=450, stretch="always")
        self.main_splitter.add(right, minsize=450, stretch="always")
        right.add(top_right,    minsize=220, stretch="always")
        right.add(bottom_right, minsize=160, stretch="always")

    def _build_statusbar(self):
        bar = tk.Frame(self.root, bg=COLORS["bg_elevated"], pady=4, padx=12)
        bar.grid(row=6, column=0, sticky="ew")

        def stat_item(parent, key):
            f = tk.Frame(parent, bg=COLORS["bg_elevated"])
            f.pack(side=tk.LEFT, padx=6)
            tk.Label(f, text=key + ":", bg=COLORS["bg_elevated"], fg=COLORS["text_dim"], font=("Consolas", 8, "bold")).pack(side=tk.LEFT, padx=(0, 2))
            lbl_v = tk.Label(f, text="--", bg=COLORS["bg_elevated"], fg=COLORS["text_secondary"], font=("Consolas", 8))
            lbl_v.pack(side=tk.LEFT)
            return lbl_v

        self.lbl_conn  = stat_item(bar, "ESTADO")
        self.lbl_iface = stat_item(bar, "INTERFAZ")
        self.lbl_type  = stat_item(bar, "TIPO")
        self.lbl_ipv4  = stat_item(bar, "IPv4")
        self.lbl_ipv6  = stat_item(bar, "IPv6")
        self.lbl_mac   = stat_item(bar, "MAC")
        self.lbl_net   = stat_item(bar, "RED")

        for label in [self.lbl_conn, self.lbl_iface, self.lbl_type, self.lbl_ipv4, self.lbl_ipv6, self.lbl_mac]:
            tk.Label(label.master.master, text="│", bg=COLORS["bg_elevated"], fg=COLORS["border_mid"], font=("Consolas", 8)).pack(side=tk.LEFT)

        tk.Label(bar, text="v2.2.0 (PROMISCUO) // CUCEI", bg=COLORS["bg_elevated"], fg=COLORS["text_dim"], font=("Consolas", 8)).pack(side=tk.RIGHT)

    def _log(self, text, tag="body"):
        self.inspector_text.insert(tk.END, text, tag)

    def _log_info(self, msg):
        self.inspector_text.insert(tk.END, "\n  ", "dim")
        self.inspector_text.insert(tk.END, msg + "\n", "dim")

    def _es_iface_virtual(self, nombre):
        n = nombre.lower()
        return (n == "lo" or n.startswith(IFACES_VIRTUALES)
                or any(k in n for k in ("loopback", "virtual", "vbox", "vmware", "vethernet")))

    def _iface_ruta_por_defecto(self):
        """Interfaz de la ruta por defecto (Linux: /proc/net/route; otros SO: netifaces si existe)."""
        if platform.system() == "Linux":
            try:
                candidatas = []
                with open("/proc/net/route") as f:
                    next(f)  # encabezado
                    for linea in f:
                        c = linea.split()
                        # destino 0.0.0.0 y flag RTF_GATEWAY (0x2) => ruta por defecto
                        if len(c) > 6 and c[1] == "00000000" and int(c[3], 16) & 2:
                            candidatas.append((int(c[6]), c[0]))   # (métrica, interfaz)
                if candidatas:
                    return min(candidatas)[1]
            except (OSError, ValueError, StopIteration):
                logging.debug("No se pudo leer /proc/net/route", exc_info=True)
        if netifaces is not None:
            try:
                gw = netifaces.gateways().get("default", {}).get(netifaces.AF_INET)
                if gw:
                    return gw[1]
            except Exception:
                logging.debug("netifaces no pudo obtener el gateway", exc_info=True)
        return None

    def get_active_interface(self):
        ruta = self._iface_ruta_por_defecto()
        if ruta and not self._es_iface_virtual(ruta):
            return ruta
        for nombre, addrs in psutil.net_if_addrs().items():
            if self._es_iface_virtual(nombre):
                continue
            for a in addrs:
                if a.family == socket.AF_INET and not a.address.startswith(("169.254.", "127.")):
                    return nombre
        return None

    def listar_interfaces(self):
        """Lista [(etiqueta, nombre)] de las tarjetas Wi-Fi / Ethernet disponibles (con o sin IP)."""
        try:
            addrs = psutil.net_if_addrs()
            stats = psutil.net_if_stats()
        except Exception:
            logging.exception("No se pudieron listar las interfaces")
            return []
        resultado = []
        for nombre in sorted(addrs):
            if self._es_iface_virtual(nombre):
                continue
            ipv4 = next((a.address for a in addrs[nombre] if a.family == socket.AF_INET), None)
            activa = stats[nombre].isup if nombre in stats else False
            estado = ipv4 if ipv4 else ("sin IP" if activa else "desconectada")
            resultado.append((f"{self.detect_connection_type(nombre)} · {nombre}  ({estado})", nombre))
        return resultado

    def _poblar_interfaces(self):
        """Llena el desplegable de tarjetas conservando la selección si sigue existiendo."""
        opciones = self.listar_interfaces()
        self.iface_map = {etiqueta: nombre for etiqueta, nombre in opciones}
        self.combo_iface["values"] = [IFACE_AUTO] + list(self.iface_map)
        seleccion = IFACE_AUTO
        if not self.iface_auto:
            for etiqueta, nombre in opciones:
                if nombre == self.current_interface:
                    seleccion = etiqueta
                    break
            else:
                self.iface_auto = True   # la tarjeta elegida desapareció (p. ej. se desconectó el USB)
        self.combo_iface.set(seleccion)
        self._etiqueta_iface_actual = seleccion

    def _aplicar_seleccion_interfaz(self, etiqueta):
        self._etiqueta_iface_actual = etiqueta
        if etiqueta == IFACE_AUTO:
            self.iface_auto = True
            self.current_interface = self.get_active_interface()
        else:
            self.iface_auto = False
            self.current_interface = self.iface_map.get(etiqueta)
        self.update_connection_status()

    def on_cambio_interfaz(self, event=None):
        etiqueta = self.combo_iface.get()
        if etiqueta == self._etiqueta_iface_actual:
            return
        if self.sniffing:
            if not messagebox.askyesno("Cambiar tarjeta", "La captura está activa.\n¿Detenerla y cambiar de tarjeta?"):
                self.combo_iface.set(self._etiqueta_iface_actual)
                return
            self.stop_sniffing()
        self._aplicar_seleccion_interfaz(etiqueta)

    def on_cambio_protocolo(self, event=None):
        self.apps_filtro = FILTROS_PROTOCOLO.get(self.combo_proto.get())
        if self.sniffing:   # el filtro BPF se fija al abrir el socket: hay que reiniciar la captura
            self.stop_sniffing()
            self.root.after(400, self.start_sniffing)

    def refresh_interface(self):
        self._poblar_interfaces()
        if self.iface_auto and not self.sniffing:
            self.current_interface = self.get_active_interface()
        self.update_connection_status()

    def get_wifi_network_info(self):
        system = platform.system()
        ssid = channel = signal = None
        if system == "Windows":
            try:
                result = subprocess.run(["netsh", "wlan", "show", "interfaces"], capture_output=True, text=True, timeout=3)
                lines = result.stdout.splitlines()
                for line in lines:
                    if "SSID" in line and "BSSID" not in line:
                        parts = line.split(":")
                        if len(parts) > 1:
                            ssid = parts[1].strip()
                            if ssid: break
                for line in lines:
                    if "Channel" in line:
                        parts = line.split(":")
                        if len(parts) > 1: channel = parts[1].strip()
                    if "Signal" in line:
                        parts = line.split(":")
                        if len(parts) > 1: signal = parts[1].strip()
            except Exception:
                logging.debug("netsh falló", exc_info=True)
        elif system == "Linux":
            iface = self.current_interface or "wlan0"
            # 1) NetworkManager sin root y sin iwconfig
            try:
                entorno = dict(os.environ, LC_ALL="C")   # "yes" en vez de "sí"
                result = subprocess.run(
                    ["nmcli", "-t", "-f", "ACTIVE,SSID,CHAN,SIGNAL", "dev", "wifi", "list", "ifname", iface],
                    capture_output=True, text=True, timeout=3, env=entorno)
                for linea in result.stdout.splitlines():
                    campos = re.split(r"(?<!\\):", linea)   # los ':' dentro del SSID vienen escapados
                    if len(campos) >= 4 and campos[0] == "yes":
                        ssid = campos[1].replace("\\:", ":")
                        channel = campos[2]
                        signal = f"{campos[3]}%"
                        break
            except (OSError, subprocess.SubprocessError):
                logging.debug("nmcli no disponible", exc_info=True)
            # 2) Respaldo: iwconfig (paquete wireless-tools)
            if not ssid:
                try:
                    result = subprocess.run(["iwconfig", iface], capture_output=True, text=True, timeout=3)
                    for line in result.stdout.splitlines():
                        if "ESSID:" in line: ssid = line.split("ESSID:")[1].strip().strip('"')
                        if "Frequency:" in line:
                            p = line.split("Frequency:")
                            if len(p) > 1: channel = p[1].split()[0]
                        if "Signal level=" in line:
                            p = line.split("Signal level=")
                            if len(p) > 1: signal = p[1].split()[0]
                except (OSError, subprocess.SubprocessError):
                    logging.debug("iwconfig no disponible", exc_info=True)
        return ssid, channel, signal

    def get_ethernet_network_info(self, iface_name):
        speed = duplex = None
        system = platform.system()
        if system == "Windows":
            try:
                cmd = f'powershell -command "Get-NetAdapter -Name \\"{iface_name}\\" | Select-Object Name, LinkSpeed"'
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=3, shell=True)
                for line in result.stdout.splitlines():
                    if "LinkSpeed" in line:
                        parts = line.split(":")
                        if len(parts) > 1: speed = parts[1].strip()
            except: pass
        elif system == "Linux":
            try:
                sp = f"/sys/class/net/{iface_name}/speed"
                dp = f"/sys/class/net/{iface_name}/duplex"
                if os.path.exists(sp):
                    with open(sp) as f:
                        v = f.read().strip()
                        if v and v != "-1": speed = f"{v} Mbps"
                if os.path.exists(dp):
                    with open(dp) as f: duplex = f.read().strip()
            except: pass
        return speed, duplex

    def get_network_name(self):
        if not self.current_interface: return "No conectado"
        conn_type = self.detect_connection_type(self.current_interface)
        if "Wi-Fi" in conn_type:
            ssid, channel, signal = self.get_wifi_network_info()
            if ssid:
                info = ssid
                if channel: info += f"  ch.{channel}"
                if signal:  info += f"  sig:{signal}"
                return info
            return "Wi-Fi (SSID oculto)"
        elif "Ethernet" in conn_type:
            speed, duplex = self.get_ethernet_network_info(self.current_interface)
            info = "Ethernet"
            if speed:  info += f"  {speed}"
            if duplex: info += f"  {duplex}"
            return info
        return "Red desconocida"

    def get_interface_addresses(self, iface_name):
        ipv4 = None; ipv6_list = []; mac = None
        try:
            for addr in psutil.net_if_addrs().get(iface_name, []):
                if addr.family == socket.AF_INET:
                    if ipv4 is None: ipv4 = addr.address
                elif addr.family == socket.AF_INET6:
                    ip6 = addr.address.split('%')[0]
                    if ip6 not in ipv6_list: ipv6_list.append(ip6)
                elif addr.family == psutil.AF_LINK:
                    mac = addr.address
        except Exception:
            logging.debug("No se pudieron leer las direcciones de %s", iface_name, exc_info=True)
        return ipv4, ipv6_list, mac

    def detect_connection_type(self, iface_name):
        if platform.system() == "Linux":
            # sysfs es la fuente fiable: wlo1, wlp2s0, wlan0... todas tienen /wireless
            if os.path.isdir(f"/sys/class/net/{iface_name}/wireless") or os.path.exists(f"/sys/class/net/{iface_name}/phy80211"):
                return "Wi-Fi"
        nombre = iface_name.lower()
        if nombre.startswith("wl") or any(k in nombre for k in ("wlan", "wifi", "wi-fi", "wireless", "inalámbrica")):
            return "Wi-Fi"
        return "Ethernet"

    def update_connection_status(self):
        if not self.current_interface:
            self.lbl_conn.config(text="--")
            return
        ipv4, ipv6_list, mac = self.get_interface_addresses(self.current_interface)
        conn_type = self.detect_connection_type(self.current_interface)
        network   = self.get_network_name()

        ipv6_display = "no asignada"
        if ipv6_list:
            g6 = [x for x in ipv6_list if not x.startswith('fe80') and x != '::1']
            src = g6[0] if g6 else ipv6_list[0]
            ipv6_display = src[:36] + ("…" if len(src) > 36 else "")

        self.net_iface_var.set(self.current_interface[:30])
        self.net_type_var.set(conn_type)
        self.net_ipv4_var.set(ipv4 if ipv4 else "no asignada")
        self.net_ipv6_var.set(ipv6_display)
        self.net_mac_var.set(mac if mac else "--")
        self.net_ssid_var.set(network)

        self.lbl_conn.config(text="● ACTIVA", fg=COLORS["accent_green"])
        self.lbl_iface.config(text=self.current_interface[:30])
        self.lbl_type.config(text=conn_type)
        self.lbl_ipv4.config(text=ipv4 if ipv4 else "no asignada")
        self.lbl_ipv6.config(text=ipv6_display)
        self.lbl_mac.config(text=mac if mac else "--")
        self.lbl_net.config(text=network)

    def start_network_monitor(self):
        def update():
            try:
                if not self.sniffing:
                    opciones = self.listar_interfaces()
                    if [etiqueta for etiqueta, _ in opciones] != list(self.iface_map):
                        self._poblar_interfaces()      # se conectó/desconectó una tarjeta o cambió su IP
                        self.update_connection_status()
                    if self.iface_auto:
                        new_iface = self.get_active_interface()
                        if new_iface != self.current_interface:
                            self.current_interface = new_iface
                            self.update_connection_status()
            except Exception:
                logging.exception("Error en el monitor de red")
            finally:
                self.root.after(5000, update)
        self.root.after(5000, update)

    def _extract_pkt_info(self, pkt):
        mac_src = pkt[Ether].src if pkt.haslayer(Ether) else "ff:ff:ff:ff:ff:ff"
        mac_dst = pkt[Ether].dst if pkt.haslayer(Ether) else "ff:ff:ff:ff:ff:ff"
        
        if pkt.haslayer(ARP):
            ip_src, ip_dst = pkt[ARP].psrc, pkt[ARP].pdst
            proto = "ARP"
        elif pkt.haslayer(IP):   
            ip_src, ip_dst = pkt[IP].src, pkt[IP].dst
            if pkt.haslayer(ICMP): proto = "ICMP"
            elif pkt.haslayer(TCP):  proto = "TCP"
            elif pkt.haslayer(UDP):  proto = "UDP"
            else: proto = f"IPv4 (0x{pkt[IP].proto:02x})"
        elif pkt.haslayer(IPv6): 
            ip_src, ip_dst = pkt[IPv6].src, pkt[IPv6].dst
            if pkt.haslayer(TCP):  proto = "TCP"
            elif pkt.haslayer(UDP):  proto = "UDP"
            elif pkt[IPv6].nh == 58 or obtener_icmpv6(pkt) is not None: proto = "ICMPv6"
            else: proto = f"IPv6 (0x{pkt[IPv6].nh:02x})"
        else:                    
            ip_src, ip_dst = "---", "---"
            proto = "Otro"
            
        return mac_src, mac_dst, ip_src, ip_dst, proto

    def _on_packet(self, pkt):
        """Se ejecuta en el HILO DE CAPTURA: clasifica, filtra y encola. No toca la GUI."""
        if not self.sniffing:
            return
        try:
            try:
                app, info = clasificar_aplicacion(pkt, self.rpc_calls)
            except Exception:
                logging.debug("No se pudo analizar la capa de aplicación", exc_info=True)
                app, info = None, ""
            if self.apps_filtro is not None and app not in self.apps_filtro:
                return
            self.cola.put_nowait((pkt, app, info))
        except queue.Full:
            pass   # la GUI no alcanza el ritmo: se descarta (protege la memoria)

    @staticmethod
    def _tag_l4(proto):
        for t in ("TCP", "UDP", "ICMP", "ARP"):
            if t in proto:
                return t
        return "Otro"

    def _agregar_paquete(self, pkt, app, info):
        """Se ejecuta en el HILO DE LA GUI. Devuelve el id de la fila insertada."""
        idx = len(self.paquetes)
        self.paquetes.append(pkt)
        mac_src, mac_dst, ip_src, ip_dst, proto = self._extract_pkt_info(pkt)
        tag_l4 = self._tag_l4(proto)
        if not info:
            info = info_generica(pkt)
        fila = self.tree_lista.insert(
            "", tk.END,
            values=(idx, app or proto, mac_src, mac_dst, ip_src, ip_dst, info),
            tags=(app or tag_l4, "even" if idx % 2 == 0 else "odd"))

        self.counter_total.increment()
        {"TCP": self.counter_tcp, "UDP": self.counter_udp, "ICMP": self.counter_icmp,
         "ARP": self.counter_arp}.get(tag_l4, self.counter_other).increment()
        if app in self.contadores_app:
            self.contadores_app[app].increment()
        return fila

    def _drain_queue(self):
        """Vacía la cola por lotes cada 100 ms: la GUI nunca se satura por ráfagas de tráfico."""
        try:
            self._vigilar_captura()
            ultimo = None
            for _ in range(300):
                if len(self.paquetes) >= MAX_PAQUETES:
                    self._limite_alcanzado()
                    break
                try:
                    pkt, app, info = self.cola.get_nowait()
                except queue.Empty:
                    break
                ultimo = self._agregar_paquete(pkt, app, info)
            if ultimo is not None:
                self.tree_lista.see(ultimo)
        except Exception:
            logging.exception("Error procesando la cola de paquetes")
        finally:
            self.root.after(100, self._drain_queue)

    def _vigilar_captura(self):
        """Si el hilo del sniffer murió (sin permisos, interfaz caída, BPF inválido), avisa."""
        s = self.sniffer
        if not self.sniffing or s is None:
            return
        hilo = getattr(s, "thread", None)
        if hilo is not None and not hilo.is_alive():
            iface = self.current_interface
            error = getattr(s, "exception", None)
            self.stop_sniffing()
            messagebox.showerror(
                "Error de captura",
                f"La captura en '{iface}' terminó inesperadamente.\n\n"
                f"{error or 'Revisa: permisos (root o setcap cap_net_raw), que tcpdump esté instalado y que la interfaz exista.'}")

    def _limite_alcanzado(self):
        if self.sniffing:
            self.stop_sniffing()
            self._log(f"\n◈ LÍMITE DE {MAX_PAQUETES:,} PAQUETES ALCANZADO\n  Usa LIMPIAR DATOS para seguir capturando.\n", "header")
        self._vaciar_cola()

    def _vaciar_cola(self):
        while True:
            try:
                self.cola.get_nowait()
            except queue.Empty:
                break

    def start_sniffing(self):
        if self.sniffing:
            return
        if not self.current_interface:
            self.current_interface = self.get_active_interface()
            if not self.current_interface:
                messagebox.showwarning("Advertencia", "No se detectó interfaz de red.\nElige una tarjeta en el desplegable.")
                return
            self.update_connection_status()

        apps = self.apps_filtro
        bpf = bpf_para(apps)
        nombre_filtro = self.combo_proto.get()
        self.sniffing = True
        self.start_btn.config_state(tk.DISABLED)
        self.stop_btn.config_state(tk.NORMAL)
        self.status_badge.set_active(True)
        self.status_label_top.config(text="CAPTURANDO" if not apps else f"CAPTURANDO · {nombre_filtro.split(' (')[0]}", fg=COLORS["accent_green"])
        self.inspector_text.delete(1.0, tk.END)
        self._log("◈ MONITOREO PROMISCUO INICIADO\n", "header")
        self._log("  Interfaz: ", "label")
        self._log(f"{self.current_interface}\n", "value")
        self._log("  Protocolo: ", "label")
        self._log(f"{nombre_filtro}\n", "value")
        self._log("  Filtro BPF: ", "label")
        self._log(f"{bpf or '(ninguno)'}\n", "value")
        self._log("  Inicio:   ", "label")
        self._log(f"{time.strftime('%Y-%m-%d %H:%M:%S')}\n\n", "value")

        conf.sniff_promisc = True   # necesario para ver tráfico espejeado (SPAN) que no va dirigido a la dirección MAC interceptora
        self.sniffer = AsyncSniffer(iface=self.current_interface, filter=bpf,
                                    prn=self._on_packet, store=False)
        self.sniffer.start()

    def stop_sniffing(self):
        self.sniffing = False
        sniffer, self.sniffer = self.sniffer, None
        if sniffer is not None:
            self._detener_sniffer(sniffer)
        self.start_btn.config_state(tk.NORMAL)
        self.stop_btn.config_state(tk.DISABLED)
        self.status_badge.set_active(False)
        self.status_label_top.config(text="INACTIVO", fg=COLORS["text_dim"])
        self._log(f"\n◈ CAPTURA FINALIZADA  —  {time.strftime('%H:%M:%S')}\n", "header")

    def _detener_sniffer(self, sniffer, intentos=5):
        """Detiene el AsyncSniffer sin bloquear la GUI; reintenta si se pidió parar justo al arrancar."""
        try:
            sniffer.stop(join=False)
        except Exception:
            hilo = getattr(sniffer, "thread", None)
            if intentos > 0 and hilo is not None and hilo.is_alive():
                self.root.after(300, lambda: self._detener_sniffer(sniffer, intentos - 1))
            else:
                logging.debug("El sniffer ya estaba detenido", exc_info=True)

    def limpiar_tabla(self):
        self._vaciar_cola()
        self.paquetes = []
        self.rpc_calls.clear()
        for item in self.tree_lista.get_children(): self.tree_lista.delete(item)
        for item in self.tree_detalles.get_children(): self.tree_detalles.delete(item)
        self.inspector_text.delete(1.0, tk.END)
        for c in [self.counter_total, self.counter_tcp, self.counter_udp, self.counter_icmp, self.counter_arp,
                  self.counter_other, *self.contadores_app.values()]:
            c.reset()
        self._log("◈ DATOS RESETEADOS\n", "header")

    def cargar_capas_paquete(self, event):
        sel = self.tree_lista.selection()
        if not sel: return
        for item in self.tree_detalles.get_children(): self.tree_detalles.delete(item)

        idx = int(self.tree_lista.item(sel[0], "values")[0])
        pkt = self.paquetes[idx]

        if pkt.haslayer(Ether):
            r = self.tree_detalles.insert("", tk.END, text="▸  CAPA 2  ·  Frame Ethernet (Direccionamiento Físico)", values=("",), open=True)
            self.tree_detalles.insert(r, tk.END, text="MAC Origen",      values=(pkt[Ether].src,))
            self.tree_detalles.insert(r, tk.END, text="MAC Destino",     values=(pkt[Ether].dst,))
            self.tree_detalles.insert(r, tk.END, text="Tipo Protocolo",  values=(hex(pkt[Ether].type),))

        if pkt.haslayer(ARP):
            r = self.tree_detalles.insert("", tk.END, text="▸  CAPA 2/3  ·  Protocolo ARP (Address Resolution Protocol)", values=("",), open=True)
            op_tipo = f"{pkt[ARP].op} (who-has / Request)" if pkt[ARP].op == 1 else f"{pkt[ARP].op} (is-at / Reply)"
            fields = [
                ("Tipo de Hardware (hwtype)",  hex(pkt[ARP].hwtype)),
                ("Tipo de Protocolo (ptype)",  hex(pkt[ARP].ptype)),
                ("Tamaño Hardware (hwlen)",    f"{pkt[ARP].hwlen} bytes"),
                ("Tamaño Protocolo (plen)",    f"{pkt[ARP].plen} bytes"),
                ("Operación (op)",             op_tipo),
                ("MAC Emisor ARP (hwsrc)",     pkt[ARP].hwsrc),
                ("IP Emisor ARP (psrc)",       pkt[ARP].psrc),
                ("MAC Destino ARP (hwdst)",    pkt[ARP].hwdst),
                ("IP Destino ARP (pdst)",      pkt[ARP].pdst),
            ]
            for name, val in fields: self.tree_detalles.insert(r, tk.END, text=name, values=(val,))

        if pkt.haslayer(IP):
            r = self.tree_detalles.insert("", tk.END, text="▸  CAPA 3  ·  Datagrama IPv4 (Direccionamiento Lógico)", values=("",), open=True)
            fields = [
                ("Versión",              pkt[IP].version),
                ("IHL (Header Length)",  f"{pkt[IP].ihl * 4} bytes"),
                ("Tipo de Servicio (ToS)", pkt[IP].tos),
                ("Longitud Total",       f"{pkt[IP].len} bytes"),
                ("Identificación ID",    pkt[IP].id),
                ("Flags IP",             str(pkt[IP].flags)),
                ("Fragment Offset",      pkt[IP].frag),
                ("TTL (Time To Live)",   pkt[IP].ttl),
                ("Protocolo Superior",   pkt[IP].proto),
                ("Checksum IP",          hex(pkt[IP].chksum)),
                ("IP Origen",            pkt[IP].src),
                ("IP Destino",           pkt[IP].dst),
            ]
            for name, val in fields: self.tree_detalles.insert(r, tk.END, text=name, values=(val,))

        elif pkt.haslayer(IPv6):
            r = self.tree_detalles.insert("", tk.END, text="▸  CAPA 3  ·  Datagrama IPv6 (Próxima Generación)", values=("",), open=True)
            fields = [
                ("Versión",                  pkt[IPv6].version),
                ("Clase de Tráfico (tc)",    pkt[IPv6].tc),
                ("Etiqueta de Flujo (fl)",   pkt[IPv6].fl),
                ("Longitud de Carga (plen)", f"{pkt[IPv6].plen} bytes"),
                ("Siguiente Encabezado (nh)",pkt[IPv6].nh),
                ("Límite de Saltos (hlim)",  pkt[IPv6].hlim),
                ("IP Origen v6",             pkt[IPv6].src),
                ("IP Destino v6",            pkt[IPv6].dst),
            ]
            for name, val in fields: self.tree_detalles.insert(r, tk.END, text=name, values=(val,))

        if pkt.haslayer(TCP):
            r = self.tree_detalles.insert("", tk.END, text="▸  CAPA 4  ·  Segmento TCP (Protocolo Control de Transmisión)", values=("",), open=True)
            fields = [
                ("Puerto Origen",             pkt[TCP].sport),
                ("Puerto Destino",            pkt[TCP].dport),
                ("Número de Secuencia",       pkt[TCP].seq),
                ("Acknowledgment (ACK Num)",  pkt[TCP].ack),
                ("Data Offset",               pkt[TCP].dataofs),
                ("Flags TCP",                 str(pkt[TCP].flags)),
                ("Ventana (Window Size)",     pkt[TCP].window),
                ("Checksum TCP",              hex(pkt[TCP].chksum)),
                ("Urg Pointer",               pkt[TCP].urgptr),
            ]
            for name, val in fields: self.tree_detalles.insert(r, tk.END, text=name, values=(val,))

        elif pkt.haslayer(UDP):
            r = self.tree_detalles.insert("", tk.END, text="▸  CAPA 4  ·  Datagrama UDP (Protocolo Datagramas de Usuario)", values=("",), open=True)
            fields = [
                ("Puerto Origen",  pkt[UDP].sport),
                ("Puerto Destino", pkt[UDP].dport),
                ("Longitud UDP",   f"{pkt[UDP].len} bytes"),
                ("Checksum UDP",   hex(pkt[UDP].chksum)),
            ]
            for name, val in fields: self.tree_detalles.insert(r, tk.END, text=name, values=(val,))

        self._mostrar_capa_icmp(pkt)
        self._mostrar_capa_aplicacion(pkt)

    def _mostrar_capa_icmp(self, pkt):
        """Añade al árbol la sección ICMPv4 o ICMPv6 si el paquete la contiene."""
        try:
            if pkt.haslayer(ICMP):
                d, v = icmp4_resumen(pkt), "ICMPv4"
                titulo = "▸  CAPA 3  ·  ICMPv4 (Internet Control Message Protocol)"
            elif pkt.haslayer(IPv6):
                d, v = icmp6_resumen(pkt), "ICMPv6"
                titulo = "▸  CAPA 3  ·  ICMPv6 (Mensajes de control y Neighbor Discovery)"
            else:
                return
            if not d:
                return
            r = self.tree_detalles.insert("", tk.END, text=titulo, values=("",), open=True)
            cod = f"{d['codigo']} ({d['codigo_texto']})" if d["codigo_texto"] else str(d["codigo"])
            filas = [(f"{v} Tipo", f"{d['tipo']} ({d['nombre']})"),
                     (f"{v} Código", cod),
                     (f"{v} Checksum", _hex(d["cksum"]))]
            filas += [(f"{v} {n}", val) for n, val in d["extra"]]
            for name, val in filas:
                self.tree_detalles.insert(r, tk.END, text=name, values=(val,))
        except Exception:
            logging.debug("No se pudo analizar ICMP", exc_info=True)

    def _mostrar_capa_aplicacion(self, pkt):
        """Añade al árbol la capa 7 (DNS / DHCP / HTTP / NFS) si el paquete la contiene."""
        try:
            app, _ = clasificar_aplicacion(pkt, self.rpc_calls)
            if app is None:
                return

            def seccion(titulo):
                return self.tree_detalles.insert("", tk.END, text=titulo, values=("",), open=True)

            def fila(padre, nombre, valor):
                self.tree_detalles.insert(padre, tk.END, text=nombre, values=(valor,))

            payload = bytes(pkt[Raw].load) if pkt.haslayer(Raw) else b""

            if app == "DNS" and pkt.haslayer(DNS):
                d = dns_resumen(pkt)
                r = seccion("▸  CAPA 7  ·  DNS (Domain Name System)")
                fila(r, "DNS ID de transacción", f"0x{d['id']:04x}")
                fila(r, "DNS Tipo de mensaje (QR)", "Respuesta (1)" if d["qr"] else "Consulta (0)")
                fila(r, "DNS Código de respuesta (RCODE)", f"{d['rcode']} ({RCODES_DNS.get(d['rcode'], '?')})")
                banderas = [n for n, v in (("AA", d["aa"]), ("TC", d["tc"]), ("RD", d["rd"]), ("RA", d["ra"])) if v]
                fila(r, "DNS Flags", ", ".join(banderas) or "-")
                for nombre, tipo in d["preguntas"]:
                    fila(r, "DNS Pregunta (qname / qtype)", f"{nombre}  [{tipo}]")
                for nombre, tipo, dato, ttl in d["respuestas"]:
                    fila(r, "DNS Registro de respuesta (RR)", f"{nombre}  {tipo}  →  {dato}  (TTL {ttl}s)")

            elif app == "DHCP" and pkt.haslayer(BOOTP):
                d = dhcp_resumen(pkt)
                r = seccion("▸  CAPA 7  ·  DHCP (Dynamic Host Configuration Protocol)")
                fila(r, "DHCP Tipo de mensaje", d["tipo"])
                fila(r, "DHCP Operación (op)", {1: "1 (BOOTREQUEST)", 2: "2 (BOOTREPLY)"}.get(d["op"], str(d["op"])))
                fila(r, "DHCP ID de transacción (xid)", f"0x{d['xid']:08x}")
                fila(r, "DHCP IP del cliente (ciaddr)", d["ciaddr"])
                fila(r, "DHCP IP ofrecida (yiaddr)", d["yiaddr"])
                fila(r, "DHCP IP del servidor (siaddr)", d["siaddr"])
                fila(r, "DHCP IP del relay (giaddr)", d["giaddr"])
                fila(r, "DHCP MAC del cliente (chaddr)", d["chaddr"])
                for nombre, valor in d["opciones"]:
                    fila(r, ETIQUETAS_OPCION_DHCP.get(nombre, f"Opción: {nombre}"), valor)

            elif app == "HTTP":
                h = parse_http(payload)
                r = seccion("▸  CAPA 7  ·  HTTP (HyperText Transfer Protocol)")
                if h:
                    fila(r, "HTTP Tipo de mensaje", h["tipo"])
                    if h["tipo"] == "Petición":
                        fila(r, "HTTP Método", h["metodo"])
                        fila(r, "HTTP Recurso (URI)", h["uri"])
                        fila(r, "HTTP Versión", h["version"])
                    else:
                        fila(r, "HTTP Versión", h["version"])
                        fila(r, "HTTP Código de estado", h["codigo"])
                        fila(r, "HTTP Mensaje de estado", h["mensaje"])
                    for clave, valor in h["headers"]:
                        fila(r, clave, valor)
                    fila(r, "HTTP Cuerpo en este segmento", f"{h['cuerpo_bytes']} bytes")
                else:
                    fila(r, "HTTP Tipo de mensaje", "Segmento sin cabecera HTTP (datos o control TCP)")
                    fila(r, "HTTP Cuerpo en este segmento", f"{len(payload)} bytes")

            elif app == "NFS":
                rpc = parse_rpc(payload, pkt.haslayer(TCP))
                r = seccion("▸  CAPA 7  ·  NFS / ONC RPC (Remote Procedure Call)")
                if rpc:
                    fila(r, "RPC XID (identificador de transacción)", f"0x{rpc['xid']:08x}")
                    if rpc["tipo"] == "CALL":
                        fila(r, "RPC Tipo de mensaje", "CALL (0)")
                        fila(r, "RPC Versión", rpc["rpcvers"])
                        fila(r, "RPC Programa", f"{rpc['prog']} ({rpc['prog_nombre']})")
                        fila(r, "RPC Versión del programa", rpc["vers"])
                        fila(r, "RPC Procedimiento", f"{rpc['proc']} ({rpc['proc_nombre']})")
                    else:
                        fila(r, "RPC Tipo de mensaje", "REPLY (1)")
                        fila(r, "RPC Estado de la respuesta", rpc["estado"])
                        fila(r, "RPC Llamada asociada", self.rpc_calls.get(rpc["xid"], "no capturada"))
                else:
                    fila(r, "RPC Tipo de mensaje", "Segmento sin cabecera RPC (datos o control TCP)")
        except Exception:
            logging.exception("No se pudo mostrar la capa de aplicación")

    def inspeccionar_campo(self, event):
        sel = self.tree_detalles.selection()
        if not sel: return
        item = sel[0]
        nombre = self.tree_detalles.item(item, "text")
        valores = self.tree_detalles.item(item, "values")
        valor   = valores[0] if valores else ""

        self.inspector_text.delete(1.0, tk.END)

        if nombre in self.diccionario_campos:
            self._log(f"◈ {nombre.upper()}\n", "header")
            if valor:
                self._log("  Valor en paquete: ", "label")
                self._log(f"{valor}\n\n", "value")
            self._log("  Descripción técnica:\n", "label")
            self._log(f"  {self.diccionario_campos[nombre]}\n", "body")
        else:
            self._log(f"◈ {nombre}\n", "header")
            self._log("\n  Selecciona un campo específico\n  para ver su explicación técnica.\n", "dim")

    def inicializar_diccionario(self):
        campos = {
            "MAC Origen": "Dirección física de la tarjeta de red emisora (Capa 2 Ethernet).",
            "MAC Destino": "Dirección física de destino en el mismo segmento de red local.",
            "Tipo Protocolo": "Indica el protocolo encapsulado en la capa superior (0x0800=IPv4, 0x0806=ARP).",
            "Versión": "Indica la versión del protocolo IP utilizada (4 o 6).",
            "IHL (Header Length)": "Longitud del encabezado IP expresado en palabras de 32 bits.",
            "Tipo de Servicio (ToS)": "Mecanismo para definir prioridades y calidad de servicio (QoS).",
            "Longitud Total": "Tamaño absoluto del paquete IP en bytes (encabezado + datos).",
            "Identificación ID": "Campo utilizado para rastrear fragmentos divididos de un datagrama.",
            "Flags IP": "Indicadores que controlan si un paquete puede o no ser fragmentado.",
            "TTL (Time To Live)": "Tiempo de vida del paquete. Se reduce en 1 en cada router para evitar bucles infinitos.",
            "Protocolo Superior": "Identifica el protocolo de transporte de Capa 4 (6=TCP, 17=UDP, 1=ICMP).",
            "Checksum IP": "Valor de redundancia cíclica para comprobar que el encabezado no sufra alteraciones.",
            "IP Origen": "Dirección lógica IPv4 asignada a la máquina emisora.",
            "IP Destino": "Dirección lógica IPv4 de destino final de la transmisión.",
            "Puerto Origen": "Puerto de salida asignado dinámicamente por la aplicación que originó la sesión.",
            "Puerto Destino": "Puerto de escucha asignado al servicio que recibirá la información.",
            "Número de Secuencia": "Sincroniza el orden correcto de los bytes de datos transmitidos por TCP.",
            "Acknowledgment (ACK Num)": "Indica al emisor cuál es el número del siguiente byte que se espera recibir.",
            "Flags TCP": "Bits de control que delimitan el tipo de mensaje de control (SYN, ACK, FIN, RST, PSH).",
            "Ventana (Window Size)": "Mapea la cantidad de almacenamiento disponible en buffer que tiene el receptor.",
            "Checksum TCP": "Garantiza la integridad libre de errores tanto del encabezado como de los datos TCP.",
            "Longitud UDP": "Indica el tamaño del datagrama UDP en bytes incluyendo su propia cabecera.",
            "Checksum UDP": "Verificación matemática opcional pero recomendada de la integridad del paquete UDP.",
            "IP Origen v6": "Dirección IP lógica de 128 bits correspondiente al nodo origen.",
            "IP Destino v6": "Dirección IP lógica de 128 bits correspondiente al nodo receptor.",
            "Clase de Tráfico (tc)": "Determina prioridades de envío en redes saturadas bajo IPv6.",
            "Etiqueta de Flujo (fl)": "Mantiene el ruteo idéntico para paquetes pertenecientes al mismo flujo continuo.",
            "Longitud de Carga (plen)": "Mide el tamaño de los datos encapsulados después del encabezado de 40 bytes de IPv6.",
            "Siguiente Encabezado (nh)": "Determina el tipo de cabecera de extensión o protocolo de transporte que prosigue.",
            "Límite de Saltos (hlim)": "Equivalente exacto del TTL de IPv4; cada router descuenta 1.",
            "Data Offset": "Especifica dónde terminan las cabeceras TCP y dónde comienzan los datos crudos.",
            "Urg Pointer": "Señala la ubicación exacta donde terminan datos considerados urgentes.",
            "Fragment Offset": "Determina el orden exacto en que debe acoplarse un fragmento dentro del paquete original.",
            "Tipo de Hardware (hwtype)": "Mapea la infraestructura física sobre la que opera (0x1 indica redes Ethernet estándar).",
            "Tipo de Protocolo (ptype)": "El protocolo de red al cual ARP traduce las peticiones físicas (0x0800 para IPv4).",
            "Tamaño Hardware (hwlen)": "Tamaño de las direcciones físicas expresado en bytes; en redes de área local es 6.",
            "Tamaño Protocolo (plen)": "Tamaño de las direcciones lógicas IP; en direccionamiento IPv4 el valor es 4.",
            "Operación (op)": "Determina el rol del paquete ARP: Código 1 para solicitudes (Request), Código 2 para respuestas (Reply).",
            "MAC Emisor ARP (hwsrc)": "Dirección de hardware de la máquina que publica el mensaje ARP en la red local.",
            "IP Emisor ARP (psrc)": "Dirección IP lógica asociada al emisor que publica el mensaje ARP.",
            "MAC Destino ARP (hwdst)": "Dirección física destino. En un Request, viaja en ceros porque se desconoce.",
            "IP Destino ARP (pdst)": "Dirección IP destino de la cual se está intentando averiguar su MAC física correspondiente.",

            # ---- DNS ----
            "DNS ID de transacción": "Identificador de 16 bits que genera el cliente; la respuesta lo repite para emparejarla con su consulta.",
            "DNS Tipo de mensaje (QR)": "Bit QR: 0 = consulta enviada por el cliente, 1 = respuesta del servidor.",
            "DNS Código de respuesta (RCODE)": "Resultado de la consulta: 0 NOERROR, 2 SERVFAIL (falla del servidor), 3 NXDOMAIN (el dominio no existe), 5 REFUSED (consulta rechazada).",
            "DNS Flags": "AA = respuesta autoritativa, TC = mensaje truncado (se reintenta por TCP), RD = el cliente desea recursión, RA = el servidor ofrece recursión.",
            "DNS Pregunta (qname / qtype)": "Dominio consultado y tipo de registro pedido: A = IPv4, AAAA = IPv6, MX = servidor de correo, CNAME = alias, PTR = resolución inversa, NS = servidor de nombres.",
            "DNS Registro de respuesta (RR)": "Registro devuelto por el servidor: nombre, tipo, dato (por ejemplo la IP) y TTL, que indica cuántos segundos puede guardarse en caché.",

            # ---- DHCP ----
            "DHCP Tipo de mensaje": "Fase del proceso DORA: Discover (el cliente busca servidor), Offer (el servidor ofrece una IP), Request (el cliente la solicita), ACK (el servidor confirma). También existen NAK, Decline, Release e Inform.",
            "DHCP Operación (op)": "1 = BOOTREQUEST (mensaje del cliente), 2 = BOOTREPLY (mensaje del servidor).",
            "DHCP ID de transacción (xid)": "Número aleatorio que elige el cliente para relacionar todos los mensajes de una misma negociación.",
            "DHCP IP del cliente (ciaddr)": "IP que el cliente ya posee y está usando; es 0.0.0.0 si todavía no tiene ninguna (por ejemplo, en un Discover).",
            "DHCP IP ofrecida (yiaddr)": "'Your IP address': dirección que el servidor ofrece o asigna al cliente.",
            "DHCP IP del servidor (siaddr)": "Dirección del siguiente servidor en el arranque por red (TFTP/PXE); normalmente 0.0.0.0.",
            "DHCP IP del relay (giaddr)": "Dirección del agente relay que reenvía la petición desde otra subred; 0.0.0.0 si cliente y servidor están en la misma red.",
            "DHCP MAC del cliente (chaddr)": "Dirección física del cliente; el servidor la usa para identificarlo y asignarle una IP.",
            "Opción: IP solicitada": "Opción 50: IP que el cliente pide explícitamente (al renovar o al querer reutilizar una dirección previa).",
            "Opción: Servidor DHCP (server_id)": "Opción 54: IP del servidor DHCP que ofrece o confirma la configuración.",
            "Opción: Tiempo de arrendamiento": "Opción 51: segundos que la IP queda asignada al cliente (lease).",
            "Opción: Máscara de subred": "Opción 1: máscara de la red que recibe el cliente.",
            "Opción: Router (gateway)": "Opción 3: puerta de enlace predeterminada que debe usar el cliente.",
            "Opción: Servidores DNS": "Opción 6: servidores DNS que el cliente debe utilizar.",
            "Opción: Nombre de host": "Opción 12: nombre que el cliente anuncia de sí mismo.",
            "Opción: Dominio": "Opción 15: sufijo de dominio de la red local.",
            "Opción: Tiempo T1 (renovación)": "Opción 58: tiempo tras el cual el cliente intenta renovar con el mismo servidor (normalmente 50% del lease).",
            "Opción: Tiempo T2 (reenlace)": "Opción 59: tiempo tras el cual el cliente pide renovar a cualquier servidor (normalmente 87.5% del lease).",
            "Opción: Dirección broadcast": "Opción 28: dirección de difusión de la subred.",
            "Opción: Parámetros solicitados": "Opción 55: lista de números de opción que el cliente quiere recibir del servidor.",
            "Opción: Identificador de cliente": "Opción 61: identificador único del cliente (normalmente tipo de hardware + MAC).",
            "Opción: Clase de proveedor": "Opción 60: cadena que identifica el tipo de dispositivo o sistema (por ejemplo 'MSFT 5.0' o 'android-dhcp').",

            # ---- HTTP ----
            "HTTP Tipo de mensaje": "Petición (cliente → servidor) o Respuesta (servidor → cliente). HTTP viaja en texto plano: cualquiera en la ruta puede leerlo.",
            "HTTP Método": "Acción solicitada: GET (leer un recurso), POST (enviar datos), PUT (reemplazar), DELETE (borrar), HEAD (solo cabeceras).",
            "HTTP Recurso (URI)": "Ruta del recurso pedido dentro del servidor, incluyendo parámetros de consulta (?clave=valor).",
            "HTTP Versión": "Versión del protocolo (HTTP/1.0 o 1.1). HTTP/2 y HTTP/3 son binarios y cifrados, por eso no se interpretan aquí.",
            "HTTP Código de estado": "Resultado de la petición: 2xx éxito, 3xx redirección, 4xx error del cliente (404 = no encontrado), 5xx error del servidor.",
            "HTTP Mensaje de estado": "Texto asociado al código de estado (OK, Not Found, etc.).",
            "HTTP Cuerpo en este segmento": "Bytes de contenido que viajan en este segmento TCP; el mensaje completo puede continuar en segmentos siguientes.",
            "Host": "Nombre del servidor (host virtual) al que va dirigida la petición; obligatorio en HTTP/1.1.",
            "User-Agent": "Identifica el navegador o programa cliente y su sistema operativo.",
            "Accept": "Tipos de contenido que el cliente sabe procesar.",
            "Accept-Language": "Idiomas preferidos por el cliente.",
            "Accept-Encoding": "Compresiones que el cliente acepta (gzip, br, deflate).",
            "Content-Type": "Tipo de contenido del cuerpo (text/html, application/json, image/png...).",
            "Content-Length": "Tamaño del cuerpo del mensaje en bytes.",
            "Connection": "Indica si la conexión TCP se mantiene abierta (keep-alive) o se cierra tras la respuesta.",
            "Server": "Software que atiende la petición en el servidor web.",
            "Cookie": "Cookies que el cliente envía al servidor; pueden contener sesiones, y en HTTP sin cifrar viajan a la vista de cualquiera.",
            "Set-Cookie": "Cookie que el servidor pide al cliente que guarde.",
            "Referer": "Página desde la cual el usuario llegó a este recurso.",
            "Authorization": "Credenciales del cliente. En autenticación Basic solo están codificadas en Base64, no cifradas.",
            "Cache-Control": "Directivas que indican cómo y por cuánto tiempo puede guardarse la respuesta en caché.",
            "Date": "Fecha y hora en que se generó el mensaje.",

            # ---- NFS / ONC RPC ----
            "RPC XID (identificador de transacción)": "Número que el cliente asigna a cada llamada; la respuesta lo repite para poder emparejarlas.",
            "RPC Tipo de mensaje": "CALL (0): el cliente invoca un procedimiento remoto. REPLY (1): respuesta del servidor. NFS funciona sobre ONC RPC.",
            "RPC Versión": "Versión del protocolo ONC RPC (siempre 2).",
            "RPC Programa": "Servicio remoto invocado: 100003 = NFS, 100005 = MOUNT, 100000 = PORTMAP (rpcbind), 100021 = NLM (bloqueos).",
            "RPC Versión del programa": "Versión del servicio; para NFS suele ser 3 o 4.",
            "RPC Procedimiento": "Operación concreta. En NFSv3, por ejemplo: LOOKUP, READ, WRITE, GETATTR, READDIR. NFSv4 agrupa varias operaciones en COMPOUND.",
            "RPC Estado de la respuesta": "ACEPTADA: el servidor procesó la llamada. RECHAZADA: la rechazó (versión no soportada o fallo de autenticación).",
            "RPC Llamada asociada": "Llamada (CALL) capturada con el mismo XID; indica a qué operación responde este REPLY.",
        }
        campos.update(DICCIONARIO_ICMP)
        return campos


if __name__ == "__main__":
    root = tk.Tk()
    app = SnifferApp(root)
    root.mainloop()
